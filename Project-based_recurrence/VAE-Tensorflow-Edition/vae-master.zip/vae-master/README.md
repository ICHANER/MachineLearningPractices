# vae
a simple vae and cvae from keras

https://kexue.fm/archives/5253

## vae celeba

100 epoch, loss=11585.2258

![64x64_celeba_vae](https://raw.githubusercontent.com/bojone/vae/master/100epoch_celeba.png)


## vae_cluster

https://kexue.fm/archives/5887

## 实验环境
python 2.7 + tensorflow 1.8/1.13 + keras 2.2.4

## 交流
QQ交流群：67729435，微信群请加机器人微信号spaces_ac_cn
